# MiAI_Sleep_Detection_Pi
Use OpenCV, dlib to check for drowsiness on Raspberry Pi

Article link: http://ainoodle.tech/2020/02/26/computer-vision-pi-chuong-3-lap-dat-pi-tren-xe-hoi-de-phat-hien-tai-xe-ngu-gat/

#MìAI <br>
Fanpage: http://facebook.com/miaiblog<br>
Group trao đổi, chia sẻ: https://www.facebook.com/groups/miaigroup<br>
Website: http://ainoodle.tech<br>
Youtube: http://bit.ly/miaiyoutube<br>
